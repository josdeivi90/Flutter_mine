package io.subsuelo3d.pastor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
